package lab3test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import org.junit.Test;
import org.junit.Before;

public class NewTest {

    @Test
    public void testDivide() {
        assertEquals("6 / 3 must be 2", 2, 6 / 3);
    }

}
